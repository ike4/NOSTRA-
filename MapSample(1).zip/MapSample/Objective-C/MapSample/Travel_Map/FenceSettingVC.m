//
//  FenceSettingVC.m
//  MapSample
//
//  Created by huyuming on 2017/5/23.
//  Copyright © 2017年 gissoft. All rights reserved.
//

#import "FenceSettingVC.h"

@interface FenceSettingVC ()

@end

@implementation FenceSettingVC



- (instancetype)init {
	self = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil][0];
	self.frame = CGRectMake(0, HEIGHT_SCREEN-349, WIDTH_SCREEN, 349);
	self.fenceSettingBG.frame = self.bounds;
	[self addSubview:self.fenceSettingBG];
	return self;
}
- (instancetype)initWithFrame:(CGRect)frame{
	self = [super initWithFrame:frame];
	if (self) {
		self = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil][0];
//		self.frame = CGRectMake(0, HEIGHT_SCREEN-349, WIDTH_SCREEN, 349);
//		self.fenceSettingBG.frame = self.bounds;
//		[self addSubview:self.fenceSettingBG];
//		[self.fenceSettingBG addSubview:self.sendBG];
		
		NSLog(@"------ self 你失效了吗 %@",self);
		NSLog(@"------ _fenceSettingBG 你失效了吗 %@",_fenceSettingBG);
		NSLog(@"------ sendBG 你失效了吗 %@",self.sendBG);
		//		NSLog(@"------ _fenceSettingBG 你失效了吗 %@",_fenceSettingBG);
	}
	return self;
}


- (IBAction)sendAct:(id)sender {
	[self removeAllSubviews];
	[self removeFromSuperview];
}

- (IBAction)alarmOnAct:(id)sender {
	//	self.frame = CGRectMake(0, HEIGHT_SCREEN-100, WIDTH_SCREEN, 100);
	//	return;
	CGRect rec = _sendBG.frame;
	rec.origin.y = 218;
	_sendBG.frame = rec;
}
- (IBAction)alarmOffAct:(id)sender {
	//	CGRect rec = _sendBG.frame;
	//	rec.origin.y = _reminderTV.frame.origin.y;
	//	_sendBG.frame = rec;
	//	[_sendBG mas_updateConstraints:^(MASConstraintMaker *make) {
	//		int hei = _sendBG.frame.origin.y+_sendBG.frame.size.height;
	//		make.edges.equalTo(self.fenceSettingBG).with.insets(UIEdgeInsetsMake(_reminderTV.frame.origin.y, 0, 0, self.fenceSettingBG.frame.size.height-hei));
	////		make.height.equalTo(@100);
	////		make.left.mas_equalTo(0);
	////		make.right.mas_equalTo(0);
	////		make.top.mas_equalTo(_reminderTV.frame.origin.y);
	//	}];
	//更新约束  在某个时刻约束会被还原成frame使视图显示
	//	[self layoutIfNeeded];
	//	self.frame = CGRectMake(0, HEIGHT_SCREEN-hei, WIDTH_SCREEN, hei);
	//	_fenceSettingBG.frame = CGRectMake(0, HEIGHT_SCREEN-100, WIDTH_SCREEN, 100);
	
	//	return;
	//开始动画
	_reminderTV.hidden = YES;
	[UIView animateWithDuration:1.3 animations:^{
		//		[fenceV mas_updateConstraints:^(MASConstraintMaker *make) {
		//			make.height.equalTo(@100);
		//		}];
		[self mas_updateConstraints:^(MASConstraintMaker *make) {
			int hei = self.sendBG.frame.origin.y + self.sendBG.frame.size.height;
			//			make.edges.equalTo(self.superview).with.insets(UIEdgeInsetsMake(HEIGHT_SCREEN-hei, 0, 0, 0));
			//			make.edges.equalTo(self.superview).with.insets(UIEdgeInsetsMake(300, 0, 0, 0));
			make.height.equalTo(@(200));
			make.left.mas_equalTo(0);
			make.right.mas_equalTo(0);
			make.bottom.mas_equalTo(0);
		}];
		//更新约束  在某个时刻约束会被还原成frame使视图显示
		[self layoutIfNeeded];
	} completion:^(BOOL finished) {
		
		NSLog(@"------ self 你失效了吗 %@",self);
		NSLog(@"------ _fenceSettingBG 你失效了吗 %@",_fenceSettingBG);
	}];
	
}
@end

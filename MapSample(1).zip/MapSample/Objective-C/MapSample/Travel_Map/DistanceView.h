 
#import <UIKit/UIKit.h>

///搜索范围
typedef NS_ENUM(NSUInteger, SelectedRangeType) {
    ///3公里
    SelectedRange3Km = 0,
    ///5公里
    SelectedRange5Km = 1,
    ///全城
    SelectedRangeTypeWholeCity = 2,
};

@protocol DistanceViewDelegate <NSObject>

- (void)selectItemWithType:(SelectedRangeType)type;

@end

@interface DistanceView : UIView

///搜索范围
@property (nonatomic, assign) SelectedRangeType selectedRangeType;

///选中项Title
@property (nonatomic, strong) NSString *selectedRangeString;

@property (nonatomic, assign) id <DistanceViewDelegate>delegate;

- (void)configSelf;

@end

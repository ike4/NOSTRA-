

#import "NavigateTypesSearchCell.h"
#import "NavigteTypesSearchVC.h"
//#import "SOSReportService.h"
//#import "NavigateSearchVC.h"
//#import "BaseSearchOBJ.h"
#import "DistanceView.h"
//#import "CustomerInfo.h"

typedef NS_ENUM(NSUInteger, OrderType) {
	///默认排序
	OrderTypeDefault,
	///按距离排序
	OrderTypeDistance,
};

///排序Cell高度
#define KOrderCellHeight    50
///加载下一条Cell高度
#define KLoadMoreCellHeight    30

/////搜索联想提示Cell高度
//#define KAssociateCellHeight    44
///搜索结果Cell高度
#define KSearchResultHeight    135

@interface NavigteTypesSearchVC ()  <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, DistanceViewDelegate>  {
	
	OrderType orderType;
	
	NSArray *orderArray;
	DistanceView *citySelectView;
	
	BOOL shouldHideOrderTable;
	
	///搜索关键字联想类对象
	//    BaseSearchOBJ *baseSearchOBJ;
	//    ///搜索配置对象
	//    BasePoiSearchConfiguration *poiSearchConfig;
	///搜索结果数组
	NSMutableArray *searchResultArray;
	
	__weak IBOutlet UITextField *searchTextField;
	__weak IBOutlet UIView *buttonBGView;
	__weak IBOutlet UILabel *cityLabel;
	__weak IBOutlet UIButton *cityButton;
	__weak IBOutlet UILabel *orderLabel;
	__weak IBOutlet UIButton *orderButton;
	__weak IBOutlet UIImageView *cityStatusImage;
	__weak IBOutlet UIImageView *orderStatusImage;
	__weak IBOutlet UITableView *dataTableView;
	__weak IBOutlet UIView *coverView;
	__weak IBOutlet UIView *citySelectBGView;
	__weak IBOutlet UITableView *orderTableView;
	__weak IBOutlet NSLayoutConstraint *orderTableViewConstraintY;
	__weak IBOutlet NSLayoutConstraint *citySelectViewConstraintY;
	
	__weak IBOutlet UIView *loadingView;
	__weak IBOutlet UIActivityIndicatorView *activityView;
}


@end

@implementation NavigteTypesSearchVC

- (void)viewDidLoad {
	[super viewDidLoad];
	[self configSearchBar];
	[self configDataTableView];
	[self configFieldSearch];
	citySelectView = [[DistanceView alloc] init];
	citySelectView.frame = CGRectMake(0, 0, WIDTH_SCREEN, HEIGHT_SCREEN - 53 - 69);
	citySelectView.delegate = self;
	[citySelectView configSelf];
	[citySelectBGView addSubview:citySelectView];
	cityLabel.text = NSLocalizedString(@"Navigate_Types_Search_3Km", nil);
	orderLabel.text = NSLocalizedString(@"Navigate_Types_Search_Sort_Defult", nil);
	orderArray = @[NSLocalizedString(@"Navigate_Types_Search_Sort_Defult", nil),
			   NSLocalizedString(@"Navigate_Types_Search_Sort_Distance", nil)];
	
//	cityLabel.text = LocalizedString(@"Navigate_Types_Search_3Km", nil);
//	orderLabel.text = LocalizedString(@"Navigate_Types_Search_Sort_Defult", nil);
//	orderArray = @[LocalizedString(@"Navigate_Types_Search_Sort_Defult", nil),LocalizedString(@"Navigate_Types_Search_Sort_Distance", nil)];
	

	orderTableViewConstraintY.constant = - (HEIGHT_SCREEN - 80);
	citySelectViewConstraintY.constant = - (HEIGHT_SCREEN - 80);
}

- (void)configDataTableView {
	UIView *tableHederView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, dataTableView.width, 10)];
	tableHederView.backgroundColor = [UIColor clearColor];
	dataTableView.tableHeaderView = tableHederView;
}

- (void)configPoiSearchData     {}

- (void)configFieldSearch   {
	searchTextField.placeholder = NSLocalizedString(@"Navigate_Types_Search_Input_Address", nil);
	// hidden keybord
	UIView *customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTH_SCREEN, 25)];
	customView.backgroundColor = [UIColor clearColor];
	UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(customView.frame.size.width-35, -4, 35, 29)];
	[btn setImage:[UIImage imageNamed:@"down_normal.png"] forState:UIControlStateNormal];
	[btn setImage:[UIImage imageNamed:@"down_highlight.png"] forState:UIControlStateHighlighted];
	[btn addTarget:searchTextField action:@selector(resignFirstResponder) forControlEvents:UIControlEventTouchUpInside];
	[customView addSubview:btn];
	searchTextField.inputAccessoryView = customView;
}

- (void)configSearchBar {
	UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, searchTextField.height + 5, searchTextField.height)];
	UIImageView *leftImgView = [[UIImageView alloc] initWithFrame:CGRectMake((searchTextField.height - 18) / 2 + 5, (searchTextField.height - 18) / 2, 18, 18)];
	leftImgView.image = [UIImage imageNamed:@"Navigate_SearchBar_Icon"];
	[leftView addSubview:leftImgView];
	searchTextField.leftView = leftView;
	searchTextField.leftViewMode = UITextFieldViewModeAlways;
	searchTextField.text = self.searchTypeString;
}

- (void)viewWillAppear:(BOOL)animated   {
	[super viewWillAppear:animated];
	self.tabBarController.tabBar.hidden = YES;
}

- (void)viewDidAppear:(BOOL)animated    {
	[super viewDidAppear:animated];
	[self configPoiSearchData];
}

- (IBAction)back:(UIButton *)sender {
	if ([activityView isAnimating])     [activityView stopAnimating];
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 在地图上查看当前搜索结果
- (IBAction)viewOnMapView:(UIButton *)sender {
}

#pragma mark - 区域按钮点击事件
- (IBAction)changeCity:(UIButton *)sender {
	if (sender.tag == 100) {
		if (orderButton.tag == 101) {
			//收起排序View
			orderButton.tag = 100;
			[self changeOrderButtonTitle];
			orderStatusImage.highlighted = NO;
			[UIView animateWithDuration:.1 animations:^{
				orderTableViewConstraintY.constant = - (HEIGHT_SCREEN - 80);
				[self.view layoutIfNeeded];
			}];
		}   else    {
			coverView.backgroundColor = [UIColor colorWithWhite:0 alpha:.1];
		}
		//出现
		sender.tag = 101;
		coverView.hidden = NO;
		cityStatusImage.highlighted = YES;
		[UIView animateWithDuration:.3 animations:^{
			citySelectViewConstraintY.constant = 0;
			coverView.backgroundColor = [UIColor colorWithWhite:0 alpha:.35];
			[self.view layoutIfNeeded];
		}];
	}   else    {
		//消失
		sender.tag = 100;
		cityStatusImage.highlighted = NO;
		[UIView animateWithDuration:.3 animations:^{
			citySelectViewConstraintY.constant = - (HEIGHT_SCREEN - 80);
			coverView.backgroundColor = [UIColor colorWithWhite:0 alpha:.1];
			[self.view layoutIfNeeded];
		} completion:^(BOOL finished) {
			coverView.hidden = YES;
		}];
	}
	[self changeCityButtonTitle];
}

#pragma mark - 排序按钮点击事件
- (IBAction)changeOrder:(UIButton *)sender {
	if (sender.tag == 100) {
		if (cityButton.tag == 101) {
			//收起区域View
			cityButton.tag = 100;
			[self changeCityButtonTitle];
			cityStatusImage.highlighted = NO;
			[UIView animateWithDuration:.1 animations:^{
				citySelectViewConstraintY.constant = - (HEIGHT_SCREEN - 80);
				[self.view layoutIfNeeded];
			}];
		}   else    {
			coverView.backgroundColor = [UIColor colorWithWhite:0 alpha:.1];
			citySelectViewConstraintY.constant = - (HEIGHT_SCREEN - 80);
			[self.view layoutIfNeeded];
		}
		//出现
		sender.tag = 101;
		coverView.hidden = NO;
		orderStatusImage.highlighted = YES;
		if (orderTableView.indexPathForSelectedRow == nil)  {
			[orderTableView reloadData];
		}
		[UIView animateWithDuration:.3 animations:^{
			orderTableViewConstraintY.constant = 0;
			coverView.backgroundColor = [UIColor colorWithWhite:0 alpha:.35];
			[self.view layoutIfNeeded];
		}];
	}   else    {
		//消失
		sender.tag = 100;
		orderStatusImage.highlighted = NO;
		[UIView animateWithDuration:.3 animations:^{
			orderTableViewConstraintY.constant = - (HEIGHT_SCREEN - 80);
			coverView.backgroundColor = [UIColor colorWithWhite:0 alpha:.1];
			[self.view layoutIfNeeded];
		} completion:^(BOOL finished) {
			coverView.hidden = YES;
		}];
	}
	[self changeOrderButtonTitle];
}

#pragma mark - 改变排序以及区域按钮标题
- (void)changeCityButtonTitle   {
	if (cityButton.tag == 100) {
		//将要收起
		NSString *selectTitle = citySelectView.selectedRangeString;
		if (selectTitle.length && ![cityLabel.text isEqualToString:selectTitle]) {
			cityLabel.text = selectTitle;
			[buttonBGView layoutIfNeeded];
			//            poiSearchConfig.page = 1;
			[self search];
		}
	}
}

- (void)changeOrderButtonTitle  {
	if (orderButton.tag == 100) {
		//将要收起
		NSString *selectTitle = orderArray[orderTableView.indexPathForSelectedRow.row];
		if (![orderLabel.text isEqualToString:selectTitle]) {
			orderLabel.text = selectTitle;
			[buttonBGView layoutIfNeeded];
			
			//            poiSearchConfig.page = 1;
			[self search];
		}
	}   else    {
		//将要展开
		for (int i = 0; i < orderArray.count; i++) {
			if ([orderLabel.text isEqualToString:orderArray[i]]) {
				shouldHideOrderTable = YES;
				[orderTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0] animated:YES scrollPosition:UITableViewScrollPositionNone];
				[self tableView:orderTableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
				break;
			}
		}
	}
}



#pragma mark - UITableViewDataSource & UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView   {
	
	if (tableView == dataTableView) {
		return 3;
		return searchResultArray.count ? 3 : 0;
	}   else    {
		return 1;
	}
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section    {
	if (tableView == dataTableView) {
		switch (section) {
			case 0:
				return 1;
				break;
			case 1:
				return 10;
				return searchResultArray.count;
				break;
			case 2:
				return 1;
				return searchResultArray.count == 10;
				break;
			default:
				return 0;
				break;
		}
	}   else    {
		return orderArray.count;
	}
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath  {
	if (tableView == dataTableView) {
		return indexPath.section != 1? KLoadMoreCellHeight : KSearchResultHeight;
	}   else    {
		return KOrderCellHeight;
	}
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {
	if (tableView == dataTableView) {
		if (indexPath.section != 1) {
			UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"LoadMoreCell"];
			if (cell == nil) {
				cell = [UITableViewCell new];
				UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, dataTableView.width, KLoadMoreCellHeight)];
				titleLabel.font = [UIFont systemFontOfSize:13];
				titleLabel.textAlignment = NSTextAlignmentCenter;
				titleLabel.textColor = [UIColor colorWithWhite:.5 alpha:1];
				titleLabel.tag = 1098;
				[cell addSubview:titleLabel];
			}
			[(UILabel *)[cell viewWithTag:1098] setText:indexPath.section == 0 ? NSLocalizedString(@"Navigate_Search_Load_Previous_Result", nil) : NSLocalizedString(@"Navigate_Search_Load_Next_Result", nil)];
			return cell;
		}   else    {
			NavigateTypesSearchCell *cell = (NavigateTypesSearchCell *)[tableView dequeueReusableCellWithIdentifier:@"NavigateTypesSearchCell"];
			if (cell == nil) {
				cell = [[NSBundle mainBundle] loadNibNamed:@"NavigateTypesSearchCell" owner:self options:nil][0];
				cell.nav = self.navigationController;
			}
			//            cell.poi = searchResultArray[indexPath.row];
			[cell configSelf];
			return cell;
		}
	}   else    {
		UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"orderCell"];
		if (cell == nil) {
			cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"orderCell"];cell.selectionStyle = UITableViewCellSelectionStyleNone;
			cell.backgroundColor = [UIColor whiteColor];
			CGRect labelFrame = CGRectMake(20, 0, tableView.width - 50, cell.height);
			UILabel *titleLabel = [[UILabel alloc] initWithFrame:labelFrame];
			titleLabel.font = [UIFont systemFontOfSize:14];
			titleLabel.adjustsFontSizeToFitWidth = YES;
			titleLabel.textColor = [UIColor blackColor];
			titleLabel.textAlignment = NSTextAlignmentLeft;
			titleLabel.tag = 101;
			[cell addSubview:titleLabel];
			
			UIImageView *rightSelectionFlagView = [[UIImageView alloc] initWithFrame:CGRectMake(tableView.width - 22, (cell.height - 11) / 2, 14, 11)];
			rightSelectionFlagView.image = [UIImage imageNamed:@"common_Item_Selected"];
			rightSelectionFlagView.tag = 102;
			rightSelectionFlagView.hidden = YES;
			[cell addSubview:rightSelectionFlagView];
		}
		
		((UILabel *)[cell viewWithTag:101]).text = NONil(orderArray[indexPath.row]);
		return cell;
	}
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath   {
	
	if (tableView == dataTableView) {
		return;
	}   else    {
		UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
		[cell viewWithTag:102].hidden = YES;
	}
}

#pragma mark - 距离View选中点击回调
- (void)selectItemWithType:(SelectedRangeType)type  {
	[self performSelectorOnMainThread:@selector(changeCity:) withObject:cityButton waitUntilDone:NO];
}

#pragma mark - POI搜索及其回调
- (void)search  {}


- (void)baseSearch:(id)searchOption Error:(NSString *)errCode   {
	[activityView stopAnimating];
}

#pragma mark - ScrollView DelegateWIDTH
- (void)scrollViewDidScroll:(UIScrollView *)scrollView  {
	if ([searchTextField isFirstResponder]) {
		[searchTextField resignFirstResponder];
	}
}

#pragma mark - TextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField    {return YES;}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string    {
	if (range.location >= 30)       {
		return NO;
	}   else    {
		return YES;
	}
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField  {return YES;}

- (BOOL)textFieldShouldClear:(UITextField *)textField   {
	return YES;
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
}

@end

//
//  NavigateTypesSearchCell.m
//  Onstar
//
//  Created by Coir on 16/1/26.
//  Copyright © 2016年 Shanghai Onstar. All rights reserved.
//

#import "NavigateTypesSearchCell.h"
//#import "CarOperationWaitingVC.h"
//#import "SOSReportService.h"
//#import "SOSSearchResult.h"

@interface NavigateTypesSearchCell ()   <UIAlertViewDelegate>  {

    __weak IBOutlet UILabel *titleLabel;
    __weak IBOutlet UILabel *instanteLabel;
    __weak IBOutlet UILabel *addressLabel;
    __weak IBOutlet UIButton *sendToCarButton;
    __weak IBOutlet UIButton *phoneButton;
    
}

@end

@implementation NavigateTypesSearchCell

- (void)awakeFromNib {
}

- (void)configSelf  {}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (IBAction)sendToCar:(UIButton *)sender {}

- (IBAction)phoneCall:(UIButton *)sender {}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex    {
    if (buttonIndex) {
        [self call];
    }
}

- (void)call {}

@end

//
//  TravelSearchVC.m
//  MapSample
//
//  Created by huyuming on 2017/5/22.
//  Copyright © 2017年 gissoft. All rights reserved.
//

#import "TravelSearchVC.h"
#import "NavigteTypesSearchVC.h"


@interface TravelSearchVC ()

@end

@implementation TravelSearchVC

- (void)viewDidLoad {
	[super viewDidLoad];
	
	[self addTop_searchBtn];
	[self addSearchTypeV];
}
- (void) addSearchTypeV {
	UIView *searchTypeV = [[UIView alloc] initWithFrame:CGRectMake(0, 64, WIDTH_SCREEN, 150)];
	searchTypeV.backgroundColor = [UIColor yellowColor];
	NSArray *typeTitleArr = @[@"Parking",@"Gas Station",@"Car Wash",@"Food",@"File",@"Bank"];
	//	int index = 0;
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 3; j++) {
			UIButton *typeBtn = [[UIButton alloc]initWithFrame:CGRectMake(15+(WIDTH_SCREEN-30)/3*j, 15+65*i, (WIDTH_SCREEN-50)/3, 55)];
			[typeBtn setImage:[UIImage imageNamed:@" "] forState:UIControlStateNormal];
			[typeBtn addTarget:self action:@selector(classifyButtonAction:) forControlEvents:UIControlEventTouchUpInside];
			typeBtn.tag = 6000+i*3+j;
			[typeBtn.titleLabel setFont:[UIFont systemFontOfSize:16]];
			[typeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
			//			typeBtn.backgroundColor = [UIColor purpleColor];
			[typeBtn setTitle:typeTitleArr[i*3+j] forState:UIControlStateNormal];
			[searchTypeV addSubview:typeBtn];
		}
	}
	[self.view addSubview:searchTypeV];
	
}
- (IBAction)classifyButtonAction:(UIButton *)sender {
	NavigteTypesSearchVC *vc = [[NavigteTypesSearchVC alloc] init];
	vc.searchTypeString = sender.titleLabel.text;
	//	vc.centerPoi = [CustomerInfo sharedInstance].currentPositionPoi;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark 首页 搜索 按钮
- (void) addTop_searchBtn {
	
	UIButton *searchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
	searchBtn.frame = CGRectMake(0, 0, 60, 40);
	[searchBtn setTitle:@"Search" forState:UIControlStateNormal];
	//	[searchBtn addTarget: self action: @selector(searchAct) forControlEvents: UIControlEventTouchUpInside];
	UIBarButtonItem*rightItem = [[UIBarButtonItem alloc]initWithCustomView:searchBtn];
	self.navigationItem.rightBarButtonItem = rightItem;
	UITextField *searchTextf = [[UITextField alloc] initWithFrame:CGRectMake(45, 10 ,200, 30)];
	searchTextf.delegate = self;
	searchTextf.placeholder = @"Enter the Place";
	searchTextf.textAlignment = NSTextAlignmentCenter;
	searchTextf.font = [UIFont systemFontOfSize:14];
	searchTextf.clearButtonMode = UITextFieldViewModeWhileEditing;
	searchTextf.backgroundColor = [UIColor whiteColor];
	self.navigationItem.titleView = searchTextf;
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

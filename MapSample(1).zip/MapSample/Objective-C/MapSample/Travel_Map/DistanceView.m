 

#import "DistanceView.h"

@interface DistanceView ()  <UITableViewDataSource, UITableViewDelegate>{
    
    NSArray *provinceInfoArray;
    NSArray *selectCityInfoArray;
    __weak IBOutlet UITableView *leftTableView;
    __weak IBOutlet UITableView *rightTableView;
    
}


@end

@implementation DistanceView

- (instancetype)init    {
    self = [[NSBundle mainBundle] loadNibNamed:@"DistanceView" owner:self options:nil][0];
    if (self) {
        provinceInfoArray = @[];
        selectCityInfoArray = @[];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame     {
    self = [super initWithFrame:frame];
    DistanceView *view = [[NSBundle mainBundle] loadNibNamed:@"DistanceView" owner:self options:nil][0];
    if (view) {
        view.frame = frame;
        provinceInfoArray = @[];
        selectCityInfoArray = @[];
    }
    return view;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder   {
    self = [super initWithCoder:aDecoder];
    //    DistanceView *view = [[NSBundle mainBundle] loadNibNamed:@"DistanceView" owner:self options:nil][0];
    if (self) {
        provinceInfoArray = @[];
        selectCityInfoArray = @[];
    }
    return self;
}

- (void)configSelf  {
    //    provinceInfoArray = [Util cityInfoArray];
    provinceInfoArray = @[NSLocalizedString(@"Navigate_Types_Search_3Km", nil),
                          NSLocalizedString(@"Navigate_Types_Search_5Km", nil),
                          NSLocalizedString(@"Navigate_Types_Search_Whole_City", nil)];
    [leftTableView reloadData];
    [rightTableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section    {
    if (tableView == leftTableView) {
        return provinceInfoArray.count;
    }   else    {
        return 0;//selectCityInfoArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NormalCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"NormalCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        CGRect labelFrame = tableView == leftTableView ? CGRectMake(20, 0, leftTableView.width - 20, cell.height) : CGRectMake(20, 0, rightTableView.width - 50, cell.height);
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:labelFrame];
        titleLabel.font = [UIFont systemFontOfSize:14];
        titleLabel.adjustsFontSizeToFitWidth = YES;
        titleLabel.textColor = [UIColor blackColor];
        titleLabel.textAlignment = tableView == leftTableView ? NSTextAlignmentLeft : NSTextAlignmentRight;
        titleLabel.tag = 101;
        [cell addSubview:titleLabel];
        
        //        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, cell.height - .5, cell.width, .5)];
        //        lineView.backgroundColor = [UIColor lightGrayColor];
        //        lineView.tag = 102;
        //        [cell addSubview:lineView];
        
        UIView *leftSelectionFlagView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 3, 50)];
        leftSelectionFlagView.backgroundColor = [UIColor colorWithRed:15 / 255. green:70 / 255. blue:195 / 255. alpha:1];
        leftSelectionFlagView.tag = 103;
        leftSelectionFlagView.hidden = YES;
        [cell addSubview:leftSelectionFlagView];
        
        UIImageView *rightSelectionFlagView = [[UIImageView alloc] initWithFrame:CGRectMake(tableView.width - 22, (cell.height - 11) / 2, 14, 11)];
        rightSelectionFlagView.image = [UIImage imageNamed:@"common_Item_Selected"];
        rightSelectionFlagView.tag = 104;
        if (indexPath.row == 0)     rightSelectionFlagView.hidden = NO;
        else                        rightSelectionFlagView.hidden = YES;
        [cell addSubview:rightSelectionFlagView];
    }
    //    if (tableView == leftTableView) {
    //        [cell viewWithTag:103].hidden = YES;
    //        cell.backgroundColor = [UIColor colorWithRed:242 / 255. green:242 / 255. blue:248 / 255. alpha:1];
    ////        ((UILabel *)[cell viewWithTag:101]).text = NONil(provinceInfoArray[indexPath.row][@"ProvinceName"]);
    //        ((UILabel *)[cell viewWithTag:101]).text = NONil(provinceInfoArray[indexPath.row]);
    //    }   else    {
    cell.backgroundColor = [UIColor whiteColor];
//    [cell viewWithTag:104].hidden = YES;
    ((UILabel *)[cell viewWithTag:101]).text = NONil(provinceInfoArray[indexPath.row]);
    //    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    //    if (tableView == leftTableView) {
    ////        selectCityInfoArray = provinceInfoArray[indexPath.row][@"cities"];
    //        cell.backgroundColor = [UIColor whiteColor];
    //        [cell viewWithTag:103].hidden = NO;
    //        self.selectedAddressString = ((UILabel *)[cell viewWithTag:101]).text;
    ////        [rightTableView reloadData];
    //    }   else    {
    [cell viewWithTag:104].hidden = NO;
    self.selectedRangeString = ((UILabel *)[cell viewWithTag:101]).text;
    self.selectedRangeType = indexPath.row;
    [self.delegate selectItemWithType:self.selectedRangeType];
    //    }
    
    if (indexPath.row) {
        UITableViewCell *firstCell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        [firstCell viewWithTag:104].hidden = YES;
    }
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath   {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    //    if (tableView == leftTableView) {
    ////        selectCityInfoArray = provinceInfoArray[indexPath.row][@"cities"];
    //        cell.backgroundColor = [UIColor colorWithRed:242 / 255. green:242 / 255. blue:248 / 255. alpha:1];
    //        [cell viewWithTag:103].hidden = YES;
    //        [rightTableView reloadData];
    //    }   else    {
    [cell viewWithTag:104].hidden = YES;
    //    }
}

@end

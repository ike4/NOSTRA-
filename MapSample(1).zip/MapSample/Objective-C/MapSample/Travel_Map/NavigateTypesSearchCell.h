 

#import <UIKit/UIKit.h>

@interface NavigateTypesSearchCell : UITableViewCell

//@property (nonatomic, strong) SOSPOI *poi;
@property (nonatomic, weak) UINavigationController *nav;

- (void)configSelf;

@end

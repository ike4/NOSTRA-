//
//  NavigteTypesSearchVC.h
//  Onstar
//
//  Created by Coir on 16/1/26.
//  Copyright © 2016年 Shanghai Onstar. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "NavigateSearchMoreView.h"

@interface NavigteTypesSearchVC : UIViewController

@property (nonatomic, strong) NSString *searchTypeString;

//@property (nonatomic, strong) SOSPOI *centerPoi;

//@property (nonatomic, assign) PageType pageType;

@end

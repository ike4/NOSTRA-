//
//  FenceSettingVC.h
//  MapSample
//
//  Created by huyuming on 2017/5/23.
//  Copyright © 2017年 gissoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FenceSettingVC : UIView


@property (weak, nonatomic) IBOutlet UITextView *reminderTV;

@property (weak, nonatomic) IBOutlet UIButton *driveOutBtn;

@property (weak, nonatomic) IBOutlet UIView *sendBG;

@property (weak, nonatomic) IBOutlet UIView *fenceSettingBG;

- (IBAction)sendAct:(id)sender;
- (IBAction)alarmOnAct:(id)sender;
- (IBAction)alarmOffAct:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *alarmOnBtn;
@property (weak, nonatomic) IBOutlet UIButton *alarmOffBtn;


@end

//
//  ViewController.m
//  MapSample
//
//  Copyright © 2559 Globtech. All rights reserved.
//

#import "MapViewController.h"

#define REFERRER @""

@interface MapViewController ()

@end

@implementation MapViewController
{
	FenceSettingVC *fenceV;

}
- (void)viewDidLoad {
	[super viewDidLoad];
	self.navigationController.navigationBar.barTintColor = [UIColor blueColor];
	[self addTop_home_searchBtn];
	[self addMap];
	
}

#pragma mark 首页 搜索 按钮
- (void) addTop_home_searchBtn {
	
	UIButton *homeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
	homeBtn.frame = CGRectMake(0, 0, 60, 40);
	[homeBtn setTitle:@"Home" forState:UIControlStateNormal];
	[homeBtn addTarget:self action:@selector(addFenceSettingV) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithCustomView:homeBtn];
	self.navigationItem.leftBarButtonItem = item;
	
	UIButton *searchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
	searchBtn.frame = CGRectMake(0, 0, 60, 40);
	[searchBtn setTitle:@"Search" forState:UIControlStateNormal];
	[searchBtn addTarget: self action: @selector(searchAct) forControlEvents: UIControlEventTouchUpInside];
	UIBarButtonItem*rightItem = [[UIBarButtonItem alloc]initWithCustomView:searchBtn];
	self.navigationItem.rightBarButtonItem = rightItem;

	UITextField *searchTextf = [[UITextField alloc] initWithFrame:CGRectMake(45, 10 ,200, 30)];
	searchTextf.delegate = self;
	searchTextf.placeholder = @"Enter the Place";
	searchTextf.textAlignment = NSTextAlignmentCenter;
	searchTextf.font = [UIFont systemFontOfSize:14];
	searchTextf.clearButtonMode = UITextFieldViewModeWhileEditing;
	searchTextf.backgroundColor = [UIColor whiteColor];
	self.navigationItem.titleView = searchTextf;
}

- (void) addFenceSettingV {
//	fenceV = [[FenceSettingVC alloc] init];
	fenceV = [[FenceSettingVC alloc] initWithFrame:CGRectMake(0, HEIGHT_SCREEN-349, WIDTH_SCREEN, 349)];

	fenceV.fenceSettingBG.backgroundColor = [UIColor redColor];
	for (UIView *viw in fenceV.subviews) {
		NSLog(@"-------- %@",viw);
	}
	fenceV.reminderTV.text = @"ggggggggggggggg";
	[fenceV.driveOutBtn addTarget:self action:@selector(driveOutAct) forControlEvents:UIControlEventTouchUpInside];
	[fenceV.alarmOffBtn addTarget:self action:@selector(alarmOffAct:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:fenceV];
}
- (void)alarmOffAct:(id)sender {
//	CGRect rec = _sendBG.frame;
//	rec.origin.y = _reminderTV.frame.origin.y;
//	_sendBG.frame = rec;
//	
//	int hei = _sendBG.frame.origin.y+_sendBG.frame.size.height;
//	self.frame = CGRectMake(0, HEIGHT_SCREEN-hei, WIDTH_SCREEN, hei);
//	[fenceV removeFromSuperview];
//	fenceV.frame = CGRectMake(0, HEIGHT_SCREEN-100, WIDTH_SCREEN, 100);
//	[self.view addSubview:fenceV];
	
//	[fenceV mas_updateConstraints:^(MASConstraintMaker *make) {
//		make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(HEIGHT_SCREEN-100, 0, 0, 0));
//	}];
	
	//开始动画
	[UIView animateWithDuration:0.3 animations:^{
//		[fenceV mas_updateConstraints:^(MASConstraintMaker *make) {
//			make.height.equalTo(@100);
//		}];
		[fenceV.fenceSettingBG mas_updateConstraints:^(MASConstraintMaker *make) {
//			make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(HEIGHT_SCREEN-100, 0, 0, 0));
			make.height.equalTo(@100);
			make.left.mas_equalTo(0);
			make.right.mas_equalTo(0);
			make.bottom.mas_equalTo(0);
				}];
		//更新约束  在某个时刻约束会被还原成frame使视图显示
		[self.view layoutIfNeeded];
	} completion:^(BOOL finished) {}];
	

	
}
- (void) driveOutAct {

}


- (void) searchAct {
	TravelSearchVC *searchVC = [TravelSearchVC new];
	[self.navigationController pushViewController:searchVC animated:YES];
}


- (void) addMap {
	[_mapView setLayerDelegate:self];
	_basemaps = [@[] mutableCopy];
	_layers = [@[] mutableCopy];
	
	@try {
		NSError *error = nil;
		_mapResult = [NTMapPermissionService executeAndReturnError:&error];
		NSLog(@"-------------------- _mapResult %@ \n error    %@",_mapResult,error);
		if (!error) {
			if (_mapResult.results != nil && _mapResult.results.count > 0) {
				NSArray *mapResultSorted = [_mapResult.results sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"sortIndex" ascending:YES]]];
				for (NTMapPermissionResult *mapPermission in mapResultSorted) {
					if (mapPermission.layerType == NTMapLayerTypeBasemap || mapPermission.layerType == NTMapLayerTypeImagery) {
						[_basemaps addObject:mapPermission];
					}
					else if (mapPermission.layerType == NTMapLayerTypeSpecialLayer) {
						[_layers addObject:mapPermission];
					}
					
					if (mapPermission.serviceId == 2) {
						[self addLayer:mapPermission];
					}
					else {
						dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
							[self addLayer:mapPermission];
						});
					}
				}
			}
		}
		
	} @catch (NSException *exception) {
		
	} @finally {
		
	}

}


- (IBAction)btnShowMenu_Clicked:(id)sender {
	[self showMenu];
}

- (IBAction)btnHideMenu_Clicked:(id)sender {
	[self hideMenu];
}


- (IBAction)btnLockLocation_Clicked:(id)sender {
	[_mapView centerAtPoint:_mapView.locationDisplay.mapLocation
			   animated:true];
	NSLog(@"------- _mapView.locationDisplay.mapLocation  %@",_mapView.locationDisplay.mapLocation);
}

-(void)showMenu {
	[UIView beginAnimations:nil context: nil];
	[UIView setAnimationDuration:0.5];
	_tableViewLeading.constant = 0;
	[self.view layoutIfNeeded];
	[UIView commitAnimations];
	_btnHide.hidden = false;
}

-(void)hideMenu{
	
	[UIView beginAnimations:nil context: nil];
	[UIView setAnimationDuration:0.5];
	_tableViewLeading.constant = -260;
	[self.view layoutIfNeeded];
	[UIView commitAnimations];
	_btnHide.hidden = true;
}

- (void)visibleLayer:(BOOL)visible serviceId:(NSInteger)serviceId {
	if (_mapResult != nil && _mapResult.results.count > 0) {
		NSPredicate *predicate = [NSPredicate predicateWithFormat:@"serviceId == %d", serviceId];
		NSArray *filtered = [_mapResult.results filteredArrayUsingPredicate:predicate];
		
		if (filtered.count > 0) {
			NTMapPermissionResult *mapPer = filtered.firstObject;
			AGSLayer *layer = [_mapView mapLayerForName:mapPer.serviceName];
			if (layer != nil) {
				layer.visible = visible;
			}
			
			if (mapPer.dependMap != nil && mapPer.dependMap.count > 0) {
				for (NSNumber *serviceId in mapPer.dependMap) {
					[self visibleLayer:visible serviceId:serviceId.integerValue];
				}
			}
			
		}
	}
	
}


#pragma Layer delegate
- (void)mapViewDidLoad:(AGSMapView *)mapView
{
	[_mapView.locationDisplay startDataSource];
	
	AGSEnvelope *env = [AGSEnvelope envelopeWithXmin:10458701.000000
								  ymin:542977.875000
								  xmax:11986879.000000
								  ymax:2498290.000000
						  spatialReference:[AGSSpatialReference webMercatorSpatialReference]];
	
	[_mapView zoomToEnvelope:env animated:true];
	_mapView.backgroundColor = [UIColor purpleColor];
	NSLog(@"--------------------- -map  %@",_mapView);
}

- (void)layerDidLoad:(AGSLayer *)layer
{
	NSLog(@"%@ was loaded", layer.name);
}

- (void)layer:(AGSLayer *)layer didFailToLoadWithError:(NSError *)error
{
	NSLog(@"%@ failed to load by reason: %@",layer.name, error.description);
}

- (void)addLayer:(NTMapPermissionResult *)mapPermission {
	AGSLayer *layer = nil;
	
	NSURL *url = [[NSURL alloc] initWithString:mapPermission.serviceUrl_L];
	
	if (mapPermission.mapServiceType == NTMapServiceTypeTiledMapService) {
		
		AGSTiledMapServiceLayer *tiledLyr = nil;
		
		if (mapPermission.serviceToken_L != nil && ![mapPermission.serviceToken_L isEqual: @""]) {
			AGSCredential *cred = [[AGSCredential alloc] initWithToken:mapPermission.serviceToken_L referer:REFERRER];
			tiledLyr = [[AGSTiledMapServiceLayer alloc] initWithURL:url credential:cred];
		}
		else {
			tiledLyr = [[AGSTiledMapServiceLayer alloc] initWithURL:url];
			
		}
		tiledLyr.maxScale = 0;
		tiledLyr.delegate = self;
		layer = tiledLyr;
	}
	else if (mapPermission.mapServiceType == NTMapServiceTypeDynamicMapService) {
		AGSDynamicMapServiceLayer *dynamicLyr = nil;
		
		if (mapPermission.serviceToken_L != nil && ![mapPermission.serviceToken_L isEqual: @""]) {
			AGSCredential *cred = [[AGSCredential alloc] initWithToken:mapPermission.serviceToken_L referer:REFERRER];
			dynamicLyr = [[AGSDynamicMapServiceLayer alloc] initWithURL:url credential:cred];
		}
		else {
			dynamicLyr = [[AGSDynamicMapServiceLayer alloc] initWithURL:url];
			
		}
		
		dynamicLyr.delegate = self;
		layer = dynamicLyr;
	}
	else if (mapPermission.mapServiceType == NTMapServiceTypeFeatureService) {
		AGSFeatureLayer *featLayer = nil;
		
		if (mapPermission.serviceToken_L != nil && ![mapPermission.serviceToken_L isEqual: @""]) {
			AGSCredential *cred = [[AGSCredential alloc] initWithToken:mapPermission.serviceToken_L referer:REFERRER];
			featLayer = [[AGSFeatureLayer alloc] initWithURL:url
										  mode:AGSFeatureLayerModeOnDemand
									  credential:cred];
		}
		else {
			featLayer = [[AGSFeatureLayer alloc] initWithURL:url
										  mode:AGSFeatureLayerModeOnDemand];
		}
		
		featLayer.delegate = self;
		layer = featLayer;
	}
	else if (mapPermission.mapServiceType == NTMapServiceTypeWebMapService) {
		AGSWMSLayer *wmsLayer = nil;
		
		if (mapPermission.serviceToken_L != nil && ![mapPermission.serviceToken_L isEqual: @""]) {
			AGSCredential *cred = [[AGSCredential alloc] initWithToken:mapPermission.serviceToken_L referer:REFERRER];
			wmsLayer = [[AGSWMSLayer alloc] initWithURL:url credential:cred];
		}
		else {
			wmsLayer = [[AGSWMSLayer alloc] initWithURL:url];
		}
		wmsLayer.delegate = self;
		layer = wmsLayer;
	}
	else if (mapPermission.mapServiceType == NTMapServiceTypeOpenSteetMap) {
		AGSOpenStreetMapLayer *osmLayer = [AGSOpenStreetMapLayer openStreetMapLayer];
		layer = osmLayer;
	}
	
	if (layer != nil) {
		// layer will be visibled, if service id is 2 (Street map Thailand HD).
		layer.visible = mapPermission.serviceId == 2;
		[_mapView addMapLayer:layer withName:mapPermission.serviceName];
	}
	else {
		NSLog(@"error to intialize layer: \(mapPermission.serviceName)");
	}
}

#pragma Table view delegate
- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		
		if (_selectedBasemap != nil) {
			
			UITableViewCell *dCell = [tableView cellForRowAtIndexPath:_selectedBasemap];
			NSInteger serviceId = [self findServiceId:dCell.textLabel.text];
			
			if (serviceId > -1) {
				[self visibleLayer:NO serviceId:serviceId];
			}
			
			[tableView deselectRowAtIndexPath:_selectedBasemap animated:false];
		}
		_selectedBasemap = indexPath;
		
		
	}
	
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	NSInteger serviceId = [self findServiceId:cell.textLabel.text];
	
	if (serviceId > -1) {
		[self visibleLayer:YES serviceId:serviceId];
	}
	
	[self hideMenu];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	NSInteger serviceId = [self findServiceId:cell.textLabel.text];
	
	if (serviceId > -1) {
		[self visibleLayer:NO serviceId:serviceId];
	}
	
	[self hideMenu];
}

- (NSInteger)findServiceId:(NSString *)serviceName {
	NTMapPermissionResult *mapPermission = nil;
	
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"serviceName == %@", serviceName];
	
	NSArray *filtered = [_mapResult.results filteredArrayUsingPredicate:predicate];
	
	if (filtered.count > 0) {
		mapPermission = filtered.firstObject;
	}
	
	return mapPermission != nil ? mapPermission.serviceId : -1;
}

#pragma Table view datasource
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"header"];
	
	if (section == 0)
	{
		[cell.textLabel setText:@"Basemap"];
	}
	else
	{
		[cell.textLabel setText:@"Layer"];
	}
	
	[cell.textLabel setBackgroundColor:[UIColor clearColor]];
	
	return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
	   cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
	NTMapPermissionResult *service;
	if (indexPath.section == 0)
	{
		service = _basemaps[indexPath.row];
	}
	else
	{
		service = _layers[indexPath.row];
	}
	
	if (service.serviceId == 2) {
		_selectedBasemap = indexPath;
	}
	
	[cell.textLabel setText:service.serviceName];
	
	return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if (section == 0)
	{
		return _basemaps.count;
	}
	else
	{
		return _layers.count;
	}
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 2;
}

@end

//
//  NOSTRASDK.h
//  NOSTRASDK
//
//  Created by Itthisak Phueaksri on 2/23/2559 BE.
//  Copyright © 2559 gissoft. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NOSTRASDK.
FOUNDATION_EXPORT double NOSTRASDKVersionNumber;

//! Project version string for NOSTRASDK.
FOUNDATION_EXPORT const unsigned char NOSTRASDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NOSTRASDK/PublicHeader.h>


